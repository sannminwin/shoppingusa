-- SUMMARY --

This module creates a simple calculator in a block for the website.
Through this calculator you can perform basic mathematical operations
such +, -, /, *. Also allows you to perform calculation of decimal
values, calculate percentage of values, calculation of -ve numbers.

To perform calc operations :-

1) Install the calc module
2) Enable the calc block
